# لعبة اضرب الهدف – Android
مشروع Android بسيط مستقل، مناسب للبناء إلى APK أو AAB.

## البناء
1. افتح المجلد في Android Studio.
2. انتظر مزامنة Gradle.
3. Build > Build APK(s) لإنشاء APK تجريبي.
4. Build > Generate Signed Bundle / APK لإنشاء AAB أو APK موقّع للنشر.

اسم الحزمة: com.mehdi.targetgame
الإصدار: 1.0

ملاحظة: المشروع الحالي لا يحتوي على إعلانات أو مشتريات حقيقية. يمكن إضافتها لاحقًا قبل النشر التجاري.
