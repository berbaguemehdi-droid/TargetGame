package com.mehdi.targetgame;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    GameView game;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        game = new GameView(this);
        setContentView(game);
    }
    @Override public void onBackPressed(){
        if(game.running){ game.pauseGame(); } else super.onBackPressed();
    }

    static class GameView extends View {
        Paint p=new Paint(1); Random rnd=new Random();
        SharedPreferences prefs; float tx,ty; int score=0, coins=0, best=0, level=1;
        long endAt=0; boolean running=false, paused=false;
        Runnable ticker;
        GameView(Context c){ super(c); prefs=c.getSharedPreferences("save",0);
            best=prefs.getInt("best",0); coins=prefs.getInt("coins",0);
            p.setTypeface(Typeface.create("sans",Typeface.BOLD));
            ticker=()->{ if(running && !paused){ invalidate(); postDelayed(ticker,200); } };
        }
        void startGame(){
            score=0; level=1; running=true; paused=false; endAt=System.currentTimeMillis()+30000;
            moveTarget(); post(ticker); invalidate();
        }
        void moveTarget(){
            float r=Math.max(28, 42-level*2);
            tx=r+40+rnd.nextFloat()*Math.max(1,getWidth()-2*r-80);
            ty=170+rnd.nextFloat()*Math.max(1,getHeight()-230);
        }
        void pauseGame(){ if(running){paused=true; invalidate();} }
        void resumeGame(){paused=false; invalidate(); post(ticker);}
        void finish(){
            running=false; paused=false;
            if(score>best){best=score; prefs.edit().putInt("best",best).apply();}
            coins+=score/2; prefs.edit().putInt("coins",coins).apply();
            invalidate();
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            c.drawColor(Color.rgb(18,18,18));
            p.setColor(Color.WHITE); p.setTextSize(44); c.drawText("اضرب الهدف",40,60,p);
            p.setTextSize(24); c.drawText("النقاط: "+score,40,105,p);
            c.drawText("العملات: "+coins,220,105,p);
            c.drawText("الأفضل: "+best,40,140,p);

            if(!running){
                p.setTextSize(28); p.setColor(Color.LTGRAY);
                c.drawText("لعبة سريعة وممتعة",40,getHeight()/2-70,p);
                p.setColor(Color.rgb(103,80,164)); c.drawRoundRect(40,getHeight()/2-35,getWidth()-40,getHeight()/2+30,22,22,p);
                p.setColor(Color.WHITE); p.setTextSize(25); c.drawText("ابدأ اللعب",getWidth()/2-65,getHeight()/2+5,p);
                p.setColor(Color.LTGRAY); p.setTextSize(20);
                c.drawText("اضغط الهدف بأسرع ما يمكنك خلال 30 ثانية",40,getHeight()/2+80,p);
                c.drawText("أفضل نتيجة: "+best+"   •   عملاتك: "+coins,40,getHeight()/2+120,p);
                return;
            }
            long left=Math.max(0,endAt-System.currentTimeMillis());
            if(left==0){finish();return;}
            p.setColor(Color.WHITE); p.setTextSize(24); c.drawText("الوقت: "+(left/1000+1)+" ث",getWidth()-160,60,p);
            float r=Math.max(28,42-level*2);
            p.setColor(Color.rgb(255,82,82)); c.drawCircle(tx,ty,r,p);
            p.setColor(Color.WHITE); c.drawCircle(tx,ty,r*0.68f,p);
            p.setColor(Color.rgb(255,82,82)); c.drawCircle(tx,ty,r*0.35f,p);

            if(paused){
                p.setColor(0xCC000000); c.drawRect(0,0,getWidth(),getHeight(),p);
                p.setColor(Color.WHITE); p.setTextSize(34); c.drawText("متوقف",getWidth()/2-55,getHeight()/2-20,p);
                p.setTextSize(22); c.drawText("اضغط للمتابعة",getWidth()/2-75,getHeight()/2+25,p);
            }
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_DOWN) return true;
            float x=e.getX(), y=e.getY();
            if(!running){ startGame(); return true; }
            if(paused){resumeGame(); return true;}
            float r=Math.max(28,42-level*2);
            if(Math.hypot(x-tx,y-ty)<=r){
                score++;
                level=Math.min(10,1+score/5);
                moveTarget();
                invalidate();
            }
            return true;
        }
    }
}
